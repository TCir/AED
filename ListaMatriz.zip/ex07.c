#include <stdlib.h>
#include <stdio.h>
#include <locale.h>
#include <time.h>
#include <string.h>

// Exercicios : Matriz
// Aluno: Thiago Valentim

// 7 - Desenvolver um programa que leia o número de alunos em uma turma. (2,0)
// Em seguida:
// a) criar uma função que devolva um vetor com os nomes dos alunos.
// b) uma função que devolva uma matriz contendo quatro notas por aluno – notas do tipo inteiro.
// c) uma função que receba a matriz de notas e devolva um vetor do tipo real contendo a média de cada aluno.
// d) uma função que devolva um vetor com a classificação em ordem alfabética dos alunos da turma.
// e) uma função que receba os vetores e matrizes criados e imprima os alunos em ordem alfabética , bem como suas
// médias
const int qtdNotas = 4;
char **leiaAlunos(int nrAlunos);
int **entNotas(int nrAlunos, char **alunos);
float *caMedia(int nrAlunos, int **notas);
int *classificaAlunos(int nrAlunos, char **nomeAlunos);
void imprimeBoletimFinal(int nrAlunos, char **alunos, int *classificado, int **notas, float *media);

int main()
{
    int nrAlunos;
    char **nomeAlunos; // matriz
    int **notas;
    int **classificacao;
    float *media;

    printf("\nDigite o número de alunos: ");
    scanf("%i", &nrAlunos);

    nomeAlunos = leiaAlunos(nrAlunos); // nome.. recebe o que leiaAlunos retorna que o nrAlunos define a quantidade
    notas = entNotas(nrAlunos, nomeAlunos);
    media = caMedia(nrAlunos, notas);
    classificacao = classificaAlunos(nrAlunos, nomeAlunos);
    imprimeBoletimFinal(nrAlunos, nomeAlunos, classificacao, notas, media);
    return 0;
}
char **leiaAlunos(int nrAlunos) // retorna matriz preenchida
{
    char **alunos;

    alunos = malloc(sizeof(char *) * nrAlunos); // o primeiro * esta fazendo referência a primeira posição da matriz

    for (int i = 0; i < nrAlunos; i++)
    {
        alunos[i] = malloc(sizeof(char) * 50);
    }
    for (int i = 0; i < nrAlunos; i++)
    {
        printf("\nDigite o nome do aluno %d aluno: \n", i + 1);
        fflush(stdin);
        fgets(alunos[i], 50, stdin);
    }

    return alunos;
}
int **entNotas(int nrAlunos, char **alunos)
{
    int **notasAlunos;
    int i, j;
    notasAlunos = malloc(sizeof(int *) * nrAlunos);

    // criando uma linhda com as notas
    for (i = 0; i < nrAlunos; i++)
    {
        notasAlunos[i] = malloc(sizeof(int) * qtdNotas);
    }
    // lendo notas
    for (i = 0; i < nrAlunos; i++)
    {
        printf("\nAluno: %s", alunos[i]);
        for (j = 0; j < qtdNotas; j++)
        {
            printf("Digite a %d nota: ", j + 1);
            scanf("%d", &notasAlunos[i][j]);
        }
    }
    return notasAlunos;
}
float *caMedia(int nrAlunos, int **notas)
{

    float *mediaNotas;
    int i, j;
    float soma, media;
    mediaNotas = malloc(sizeof(float) * nrAlunos);
    for (i = 0; i < nrAlunos; i++)
    {
        soma = 0;
        for (j = 0; j < qtdNotas; j++)
        {
            soma = soma + (float)notas[i][j];
        }
        media = soma / qtdNotas;
        mediaNotas[i] = media;
    }
    return mediaNotas;
}
int *classificaAlunos(int nrAlunos, char **nomeAlunos)
{

    int i, j, aux;
    int *nomeClassificado;
    // Organizando nomes
    nomeClassificado = malloc(sizeof(int) * nrAlunos);
    for (i = 0; i < nrAlunos; i++)
    {
        nomeClassificado[i] = i;
    }
    for (i = 0; i < nrAlunos; i++)
    {
        for (j = 0; j < nrAlunos; j++)
        {
            if (strcmp(nomeAlunos[nomeClassificado[i]], nomeAlunos[nomeClassificado[j]]) > 0)
                aux = nomeClassificado[i];
            nomeClassificado[i] = nomeClassificado[j];
            nomeClassificado[j] = aux;
        }
    }
    return nomeClassificado;
}
void imprimeBoletimFinal(int nrAlunos, char **alunos, int *classificado, int **notas, float *media)
{
    int i, j;
    printf("Notas Finais em ordem alfabética de nome de aluno\n");
    printf("Ordem \t nome");
    for (i = 0; i < qtdNotas; i = i + 1)
    {
        printf("\t n%d", i + 1);
    }
    printf("\t media \n");
    for (i = 0; i < nrAlunos; i = i + 1)
    {
        printf("%d\t%s", i + 1, alunos[classificado[i]]);
        for (j = 0; j < qtdNotas; j = j + 1)
        {
            printf("\t%2d", notas[classificado[i]][j]);
        }
        printf("\t%6.2f\n", media[classificado[i]]);
    }
}