#include <stdlib.h>
#include <stdio.h>
#include <locale.h>
#include <time.h>

// Exercicios : Matriz
// Aluno: Thiago Valentim

// 1) Preencher uma matriz de 10 x 10 posições com valores aleatórios de 15 a 50 (utilize para cada número a função rand – faça uma
// função que dados os valores inicial e final devolva um número aleatório dentro deste intervalo) Em seguida imprima os índices (i,j) da
// matriz e o valor correspondente, na forma de matriz, bem como chame os módulos abaixo(0,5)

int main()
{
    srand(time(NULL));
    int matriz[10][10], vi = 15, vf = 50;
    printf("\n");
    printf("A matriz 10x10 será:\n");
    for (int i = 0; i < 10; i++)
    {
        for (int j = 0; j < 10; j++)
        {
            matriz[i][j] = rand() % (vf - vi + 1) + vi;
            printf("%3d ", matriz[i][j]);
        }
        printf("\n"); // necessário para dar espaço entre cada linha
    }
    printf("\n");
}