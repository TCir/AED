#include <stdlib.h>
#include <stdio.h>
#include <locale.h>
#include <time.h>

// Exercicios : Matriz
// Aluno: Thiago Valentim

// 4) Escreva um procedimento que receba uma matriz 10x10, peça ao usuário a posição [i,j] da matriz , e em seguida exiba o valor que esta
// na matriz nesta posição. FLAG -1(0,5)

void recebaMatriz(int matriz[10][10]);
int tam = 10;

int main()
{
    srand(time(NULL));
    int matriz[10][10];
    recebaMatriz(matriz);

    return 0;
}
void recebaMatriz(int matriz[10][10]) // procedimento para prencher matriz
{
    int i = 0, j = 0, posicaoi, posicaoj = 0, valor = 0;

    // Preenchendo a matriz
    printf("\n");
    for (int i = 0; i < 10; i++) // preenchendo a matriz percorrendo cada linha 10 posições
    {
        for (int j = 0; j < 10; j++) // preenchendo a matriz percorrendo a coluna 10 posições
        {
            matriz[i][j] = rand() % (50 - 15 + 1) + 15; // gerando randomicamente indo de 1 até 100
            printf(" %3d", matriz[i][j]);
        }
        printf("\n");
    }

    // Recebendo dados
    do
    {
        printf("\nEscolha a linha e coluna da posicao da Matriz n:");
        scanf("%d %d", &posicaoi, &posicaoj);

        for (int i = 0; i < 10; i++)
        {
            for (int j = 0; j < 10; j++)
            {
                if (i == posicaoi && j == posicaoj)
                {
                    valor = matriz[i][j];
                    printf("\nO valor selecionado é: %d\n", valor);
                    printf("\n");
                }
            }
        }
    } while ((i > 0 && j > 0));
}
