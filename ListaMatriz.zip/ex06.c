#include <stdlib.h>
#include <stdio.h>
#include <locale.h>
#include <time.h>

// Exercicios : Matriz
// Aluno: Thiago Valentim

// 6 - Escrever um programa que leia um valor e chame a função e o procedimentos criados. (0,5)
// - Construa uma função que retorne um vetor real, com valores aleatórios entre 30 e 50
// (intervalo fechado), de tamanho N – passe o tamanho N por valor.
// - Construa um procedimento para imprimir um vetor real de tamanho N – passe o vetor e o
// tamanho N por valor

float *preenche(int tam);
void imprima(float *v, int tam);

int main()
{
    float *vetor;
    int tam;
    printf("\nDigite o tamanho do vetor: ");
    scanf("%i", &tam);
    vetor = preenche(tam);
    imprima(vetor, tam);

    return 0;
}
// criando função para gerar o vetor
float *preenche(int tam) // *
{
    float *v;
    v = malloc(sizeof(float) * tam); // atribuindo o valor e o tamnho para a variavel

    for (int i = 0; i < tam; i++)
    {
        v[i] = rand() % (50 - 30 + 1) + 30;
    }
    return v;
}
// criando procedimento para imprimir função
void imprima(float *v, int tam)
{
    for (int i = 0; i < tam; i++)
    {
        printf("v[%i] = %.2f\n", i, v[i]);
    }
}
