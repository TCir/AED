#include <stdlib.h>
#include <stdio.h>
#include <locale.h>
#include <time.h>

// Exercicios : Matriz
// Aluno: Thiago Valentim

// 5) Escreva um procedimento que receba uma matriz 10x10, e um número. O procedimento deverá verificar se o número está ou não na
// matriz. Se estiver imprima a(s) posição(ões) desse número e se não estiver imprima a mensagem valor não encontrado.(0,5)

void recebeMatriz(int mat[10][10]);

int main()
{
    int mat[10][10];
    recebeMatriz(mat);

    return 0;
}
void recebeMatriz(int mat[10][10])
{

    srand(time(NULL));
    int matriz[10][10], number = 0, variavel = 0, i = 0, j = 0;

    printf("\nDigite um número e verifique se esta presente na matriz: ");
    scanf("%d", &number);

    // Preenchendo a matriz
    printf("\n");
    for (int i = 0; i < 10; i++) // preenchendo a matriz percorrendo cada linha 10 posições
    {
        for (int j = 0; j < 10; j++) // preenchendo a matriz percorrendo a coluna 10 posições
        {
            matriz[i][j] = rand() % (50 - 15 + 1) + 15; // gerando randomicamente indo de 1 até 100
            printf(" %3d", matriz[i][j]);
        }
        printf("\n");
    }
    for (int i = 0; i < 10; i++)
    {
        for (int j = 0; j < 10; j++)
        {
            if (matriz[i][j] == number) // Comparando se o numera esta presente na matriz
            {
                variavel++;
                printf("\nO numero %d esta presente na matriz na posição [%d,%d]\n", matriz[i][j], i, j);
            }
        }
    }
    if (variavel == 0)
    {
        printf("\nNúmero não encontrado.\n\n");
    }
}