#include <stdlib.h>
#include <stdio.h>
#include <locale.h>
#include <time.h>

// Exercicios : Matriz
// Aluno: Thiago Valentim
// 3) Escreva uma função que receba uma matriz 10x10 e retorne a soma dos elementos da diagonal.(0,5)

int main()
{
    srand(time(NULL));
    int matriz[10][10], somaDiagonal;
    somaDiagonal = 0; // iniciando a variavel para não levar lixo para o resultado

    // Preenchendo a matriz
    printf("\n");
    for (int i < 10; i++) // preenchendo a matriz percorrendo cada linha 10 posições
    {
        for (int j = 0; j < 10; j++) // preenchendo a matriz percorrendo a coluna 10 posições
        {
            matriz[i][j] = rand() % (50 - 15 + 1) + 15; // gerando randomicamente indo de 1 até 100
            printf(" %3d", matriz[i][j]);
        }
        printf("\n");
    }
    printf("\n");

    // efetuando a soma dos valores da diagonal
    for (int i = 0; i < 10; i++)
    {
        for (int j = 0; j < 10; j++)
        {
            if (i = 0 &&j = 1)
            {
                somaDiagonal += matriz[i][j];
            }
        }
    }
    printf("\n A soma dos números da diagonal é: %d\n", somaDiagonal);
    printf("\n");
    return 0;
}