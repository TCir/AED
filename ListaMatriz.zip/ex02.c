#include <stdlib.h>
#include <stdio.h>
#include <locale.h>
#include <time.h>

// Exercicios : Matriz
// Aluno: Thiago Valentim

// 2) Escreva um procedimento que receba uma matriz 10x10 (passagem de parâmetro), imprimir o maior e o menor elemento da matriz bem
// como a posição de cada um.(0,5)

void recebaMatriz(int mat[10][10]);
void imprimeMaioMenor(int matriz[10][10]);

int main()
{
    srand(time(NULL));
    int matriz[10][10];
    recebaMatriz(matriz); // chamando a função que irá preencher a matriz

    imprimeMaioMenor(matriz); // imprimindo a matriz e o menor e maior valor
}
void recebaMatriz(int matriz[10][10]) // procedimento para prencher matriz
{
    int maiorEle, menorEle, menorPos = 0, maiorPos = 0; // definido o limite de valores para o vetor
                                                        // definindo o maior valor para variavel

    for (int i = 0; i < 10; i++) // preenchendo a matriz percorrendo cada linha 10 posições
    {
        for (int j = 0; j < 10; j++) // preenchendo a matriz percorrendo a coluna 10 posições
        {
            matriz[i][j] = rand() % (50 - 15 + 1) + 15; // gerando randomicamente indo de 1 até 100
        }
    }
}
void imprimeMaioMenor(int matriz[10][10])
{
    int maiorEle, menorEle, maiorPosI = 0, maiorPosJ = 0, menorPosI = 0, menorPosJ, i, j;

    printf("\n");
    printf("\n\nA matriz 10x10 será:\n");
    printf("\n");
    for (int i = 0; i < 10; i++) // Preenchendo a matriz com valores aleatórios dentro do limite
    {
        for (int j = 0; j < 10; j++)
        {
            printf("%3d  ", matriz[i][j]); // imprimindo a matriz
        }
        printf("\n");
    }
    printf("\n");

    for (int i = 0; i < 10; i++)
    {
        for (int j = 0; j < 10; j++)
        {
            if (matriz[i][j] < menorEle) // Identificando qual é o menor valor
            {
                menorEle = matriz[i][j];
                menorPosI = i; // Localizando a posição 'i' do do menor valor
                menorPosJ = j; // Localizando a posição 'j' do do menor valor
            }
        }
    }
    for (int i = 0; i < 10; i++)
    {
        for (int j = 0; j < 10; j++)
        {
            if (matriz[i][j] > maiorEle) // Identificando qual é o maior valor
            {
                maiorEle = matriz[i][j];
                maiorPosI = i; // Localizando a posição 'i' do do menor valor
                maiorPosJ = j; // Localizando a posição 'j' do do menor valor
            }
        }
    }

    printf("\nO menor valor da Matriz será: %i e sua posição é: [%d][%d]", menorEle, menorPosI, menorPosJ);
    printf("\nO maior valor da Matriz será: %i e sua posição é: [%d][%d]\n", maiorEle, maiorPosI, maiorPosJ);
    printf("\n");
}
