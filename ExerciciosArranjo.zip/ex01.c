#include <stdlib.h>
#include <stdio.h>
#include <locale.h>
#include <time.h>
// Exercicios : Arranjos
// Aluno: Thiago Valentim

// 1 - Preencher um vetor de 15 posições posições com valores aleatórios de 15 a 50. Construir um vetor B do mesmo
// tipo, em que cada elemento de B deva ser o resultado do fatorial correspondente de cada elemento da matriz A.
// Apresentar A e B.

int geraNum(int vi, int vf);
double fatA(int X);

int main()
{

    srand(time(NULL));
    int vet[15], A, B;
    double vetB[15];

    A = 15;
    B = 50;

    for (int i = 0; i < 15; i++)
    {
        vet[i] = geraNum(A, B);
        printf("\n O vetor:  %i", vet[i]);
        vetB[i] = fatA(vet[i]);
        printf(" Terá o fatorial = %.0f", vetB[i]);
    }
    printf("\n\n");

    return 0;
}
int geraNum(int vi, int vf)
{
    return rand() % (vf - vi + 1) + vi;
}
double fatA(int X)
{
    double f = 1;

    for (int i = 1; i <= X; i++)
    {
        f = f * i;
    }

    return f;
}
