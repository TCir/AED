#include <stdlib.h>
#include <stdio.h>
#include <locale.h>
#include <time.h>
// Exercicios : Arranjos
// Aluno: Thiago Valentim

// 4 - Preencher um vetor A de x elementos (x deverá ser lido do teclado) com valores aleatórios de vi a vf (lidos do
// teclado) . Crie um vetor ParImpar de 2 posições e armazene no índice 0 quantos elementos de A são par e no índice 1
// quantos elementos de A são ímpar. Apresentar o vetor ParImpar. Obs.: não utilize nenhum comando
// condicional(if,switch).

// void imparPar();
// int vetorA[], x, vetorParImpar[2];

int main()
{
    srand(time(NULL));
    // declarando as variavis
    int x = 0, vetorA[x], vi, vf, vetImPar[2], parImpar[2], par = 0, impar = 0;

    // entrada de dados
    printf("\nQuantos elementos terá o vetor: ");
    scanf("%d", &x);
    printf("\nO menor valor será: ");
    scanf("%d", &vi);
    printf("\nO maior valor será: ");
    scanf("%d", &vf);
    printf("\n");

    // preenchendo o vetor com valores alatórios
    for (int i = 0; i < x; i++)
    {
        vetorA[i] = rand() % (vf - vi + 1) + vi;
        printf("%d ", vetorA[i]);

        // verificando os elementos e contanto os pares
        while (vetorA[i] % 2 == 0)
        {
            par++;
            break;
        }
        // verificando os elementos e contanto os impares
        while (vetorA[i] % 2 != 0)
        {
            impar++;
            break;
        }
    }
    printf("\n");

    // tranformando vetores
    parImpar[0] = par;
    parImpar[1] = impar;

    printf("\n");

    // imprimindo impar
    for (int i = 0; i < 2; i++)
    {
        printf("[%d]: %d\n", i, parImpar[i]);
    }
    printf("\n");
    return 0;
}
