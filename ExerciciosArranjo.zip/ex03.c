#include <stdlib.h>
#include <stdio.h>
#include <locale.h>
#include <time.h>
// Exercicios : Arranjos
// Aluno: Thiago Valentim

// 3.Preencher um vetor A de 20 elementos com valores aleatórios de vi a vf (lidos do teclado), em seguida crie um
// procedimento que inverta os elementos armazenados. Ou seja, o primeiro elemento de A passará a ser o ultimo, o
// segundo elemento passará a ser o penúltimo e assim por diante. Apresentar A.

void inverter_Vetor(int tamA, int *inverA, int *vetorA);

int main()
{
    // função para gerar números randomicos
    srand(time(NULL));

    // declarando as variáves
    int vi, vf, tamA = 20, vetorA[tamA], vetorInvert[tamA], inverA[tamA];

    // entrada de dados
    printf("\nDigite o menor valor para o vetor: ");
    scanf("%d", &vi);
    printf("\nDigite o maior valor para o vetor: ");
    scanf("%d", &vf);
    printf("\n");

    printf("\nVetor original gerado randomicamente:\n");
    // preenchendo e imprimindo o vetor com valores aleatórios
    for (int i = 0; i < tamA; i++)
    {
        vetorA[i] = rand() % (vf - vi + 1) + vi;
        printf("%d ", vetorA[i]);
    }
    printf("\n");

    // chavamando a função
    inverter_Vetor(tamA, inverA, vetorA); // quando se chama a função não precisa apresentar os tipos, apenas seus nomes

    printf("Vetor invertido:\n");
    // saida vetor invertido
    for (int i = 0; i < tamA; i++)
    {
        printf("%d ", inverA[i]);
    }
    printf("\n\n");

    return 0;
}
void inverter_Vetor(int tamA, int *inverA, int *vetorA)
{
    // invertendo os valores para o vetorInvert
    for (int i = 0, j = 19; i < tamA; i++, j--)
    {
        inverA[i] = vetorA[j];
    }
    for (int i = 0; i < tamA; i++)
    {
        vetorA[i] = inverA[i];
    }
}
