#include <stdlib.h>
#include <stdio.h>
#include <locale.h>
#include <time.h>
// Exercicios : Arranjos
// Aluno: Thiago Valentim

// 2 - Preencher dois vetores A e B de 15 posições cada com valores aleatórios de vi a vf (lidos do teclado). Construir um
// vetor C, sendo este o resultado da união dos elementos de A e B – sem repetição. Apresentar C.

void makeVetorC(int *vetorC, int valor, int *tamc);

int main()
{
    srand(time(NULL));

    // declarando as variáves
    int vi, vf, tamc = 15, vetorA[tamc], vetorB[tamc], vetorC[tamc * 2], valor = 0;
    // entrada de dados
    printf("\nDigite o valor minimo do vetor: ");
    scanf("%d", &vi);

    printf("\nDigite o valor máximo do vetor: ");
    scanf("%d", &vf);

    // gerando valores aleatorios para os vetores A e B
    for (int i = 0; i < 15; i++)
    {
        vetorA[i] = rand() % (vf - vi + 1) + vi;
        vetorB[i] = rand() % (vf - vi + 1) + vi;
    }

    makeVetorC(vetorC, valor, &tamc);

    // gerando o vetor C da função makeVetorC
    for (int i = 0; i < 30; i++)
    {
        makeVetorC(vetorC, vetorA[i], &tamc);
        makeVetorC(vetorC, vetorB[i], &tamc);
    }
    for (int i = 0; i < tamc; i++)
    {
        printf("%d\n", vetorC[i]);
    }

    return 0;
}

void makeVetorC(int *vetorC, int valor, int *tamc)
{

    int existe = 0;

    for (int i = 0; i < *tamc; i++)
    {
        if (vetorC[i] == valor)
        {
            existe = 1;
        }
    }
    if (existe == 0)
    {
        vetorC[*tamc] = valor;
        *tamc = *tamc + 1;
    }
}
