#include <stdlib.h>
#include <stdio.h>
#include <locale.h>
#include <time.h>
// Exercicios : Arranjos
// Aluno: Thiago Valentim

// 5 - Preencher um vetor A de 10 elementos com valores aleatórios de vi a vf (lidos do teclado).Ordene e imprima o
// vetor A.

int main()
{

    // declarando variaveis
    int tamVet = 10, vetA[tamVet], vi, vf, auxVet;

    // entrada de dados
    printf("\nDigite o menor valor: ");
    scanf("%i", &vi);
    printf("\nDigite o maior valor: ");
    scanf("%i", &vf);

    // gerando valores aleatórios e preenchendo o vetor
    printf("\nVetor desordenados\n\n");
    for (int i = 0; i < tamVet; i++)
    {
        vetA[i] = rand() % (vf - vi + 1) + vi;
        printf("[%d]: %d\n", i, vetA[i]);
    }

    // organizando vetor
    for (int i = 0; i < tamVet; i++)
    {
        for (int j = 0; j < tamVet; j++)
        {
            if (vetA[i] < vetA[j])
            {
                auxVet = vetA[i];
                vetA[i] = vetA[j];
                vetA[j] = auxVet;
            }
        }
    }

    // mostrando vetor ordenados
    printf("\nVetor ordenado.\n");
    for (int i = 0; i < tamVet; i++)
    {
        printf("A[%d]: %d\n", i, vetA[i]);
    }
    printf("\n\n");
}
